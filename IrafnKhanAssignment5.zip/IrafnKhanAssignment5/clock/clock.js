"use strict";
var $ = function(id) { return document.getElementById(id); };

var displayCurrentTime = function() {
    var date = new Date();
    var hour = date.getHours();
    var min = date.getMinutes();
    var sec = date.getSeconds();
    var session = "AM";
    if(hour == 0){
        hour = 12;
    }
    if(hour>12){
        hour = hour - 12;
        session = "PM";
    }
    min = padSingleDigit(min);
    sec = padSingleDigit(sec);
    document.getElementById("hours").innerText = hour;
    document.getElementById("minutes").innerText = min;
    document.getElementById("seconds").innerText = sec;
    document.getElementById("ampm").innerText = session;
    setTimeout(displayCurrentTime,1000);
    
};

var padSingleDigit = function(num) {
	if (num < 10) {	return "0" + num; }
	else { return num; }
};

window.onload = function() {
    // set initial clock display and then set interval timer to display
    // new time every second. Don't store timer object because it 
    // won't be needed - clock will just run.
    
    displayCurrentTime();
};