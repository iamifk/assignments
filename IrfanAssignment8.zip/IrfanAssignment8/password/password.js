"use strict";
$(document).ready(function () {
    var getRandomNumber = function (max) {
        var random;
        if (!isNaN(max)) {
            random = Math.random(); //value >= 0.0 and < 1.0
            random = Math.floor(random * max); //value is an integer between 0 and max - 1
            random = random + 1; //value is an integer between 1 and max
        }
        return random;
    };

    $("#generate").click(function () {
        var s = document.getElementById('num').value;
        var num = isNaN(parseInt(s)) ? 0 : parseInt(s);
        var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_-+!@";
        if (num == 0) {
            alert("Please enter a valid number");
            return;
        } else {
            var pwd = "";
            for (var i = 0; i < num; i++) {
                var rand = getRandomNumber(60);
                pwd += chars[rand];
            }
            document.getElementById("password").value = pwd;
        }

      //  $("#password").val(""); // clear previous entry

     //   var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_-+!@";

    }); // end click()

    $("#clear").click(function () {
        $("#num").val("");
        $("#password").val("");
        $("#num").focus();
    }); // end click()

    // set focus on initial load
    $("#num").focus();
}); // end ready()