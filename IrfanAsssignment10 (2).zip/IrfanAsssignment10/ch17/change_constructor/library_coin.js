"use strict";
function Ncoins(cents)
{
    this.cents = cents;
    this.isValid = function(){
        return !(isNaN(cents)||cents<0||cents>99);
    }
    this.getNumber = function(a)
    {
        var nvalue = Math.floor(cents/a);
        cents = cents % a;
        return nvalue;
    }
}
