"use strict";
$(document).ready(function () {
    $("#calculate").click(function () {
        var cents, quarters, dimes, nickels, pennies;

        // get the number of cents from the user
        cents = Math.floor(parseInt($("#cents").val()));
        var ncoins = getCoins(cents);
        if (ncoins.isValid() == false) {
            alert("Please enter a valid number between 0 and 99");
        } else {
            // calculate the numlber of quarters
            quarters = ncoins.getNumber(25);
            dimes = ncoins.getNumber(10);
            nickels = ncoins.getNumber(5);
            pennies = cents % 5;

            // display the results of the calculations
            $("#quarters").val(quarters);
            $("#dimes").val(dimes);
            $("#nickels").val(nickels);
            $("#pennies").val(pennies);

            // select cents text box for next entry
            $("#cents").select();
        }
    }); // end click()

    // set focus on initial load
    $("#cents").focus();

}); // end ready()