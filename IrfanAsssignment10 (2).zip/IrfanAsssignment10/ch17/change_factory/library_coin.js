"use strict";
var getCoins = function (cents) {
    var centsprototype = {
            isValid: function () {
                if (this.cents < 0 || this.cents > 99 || isNaN(this.cents)) {
                    return false;
                } else {
                    return true;
                }
            },
        getNumber: function (a) {
            var coins = this.cents / a;
            if (this.cents > 0) {
                this.cents = this.cents % a;
            }
            return Math.floor(coins);
        }
        };
    var cp = Object.create(centsprototype);
        cp.cents = cents;
        return cp;
};