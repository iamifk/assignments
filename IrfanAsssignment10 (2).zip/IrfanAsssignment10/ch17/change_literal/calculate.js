"use strict";
$(document).ready(function() {
    $("#calculate").click(function() {
        var quarters, dimes, nickels, pennies;
        //get the numbber of cents from the user
        coins.cents=$("#cents").val();
        coins.cents=Math.floor(parseInt(coins.cents));
        if(coins.isValid()== false){
            alert("Please enter a valid number between 0 and 99");
        }
        else{
            //calculate the number of each of the coins
            quarters=coins.getNumber(25);
            dimes=coins.getNumber(10);
            nickels=coins.getNumber(5);
            pennies=coins.cents %5;
            //display the results to boxes
            $("#quarters").val(quarters);
            $("#dimes").val(dimes);
            $("#nickels").val(nickels);
            $("#pennies").val(pennies);
            //select cents text box for next entry
            $("#cents").select();

        }
    });
    //set focus on initial load
    $("#cents").focus();
});