"use strict";
var coins={
    cents:0,
    isValid:function(){
        if (isNaN(this.cents) || this.cents < 0 || this.cents > 99) {
            return false;

    }
    else if(!isNaN(this.cents) && this.cents > 0 && this.cents < 99) {
        return true;
    }
},


    getNumber:function(a){
        var coins = this.cents/a;
    if(this.cents > 0)
        {
            this.cents = this.cents % a;
        }
    return Math.floor(coins);    
    }
};


