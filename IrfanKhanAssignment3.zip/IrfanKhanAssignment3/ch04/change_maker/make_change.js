var $ = function(id) {
    return document.getElementById(id);
};




var quarters=0;
var dimes=0;
var nickels=0;
var pennies=0;

var makeChange=function(cents) {
    quarters=cents/25;
    var remainder1=cents%25;
    $("quarters").value=parseInt(quarters);
    
    
    
    dimes=remainder1/10;
    var remainder2=remainder1%10;
    $("dimes").value=parseInt(dimes);
    
    
    
    nickels=(remainder2)/5;
    var remainder3=remainder2%5;
    $("nickels").value=parseInt(nickels);
    
    pennies=remainder3;
    $("pennies").value=parseInt(pennies);
    
    
    
    
    
    
    
    
};






var processEntry =function(){
var cents=$("cents").value;

if (isNaN(cents)) 
{
 alert("entry must be numeric");
}
else if(cents <=0 || cents > 99)
{
alert("Entry must be between 0 and 99");
}

    else{

    makeChange(cents);
        
}
};

 window.onload=function() {
     $("cents").focus();
$("calculate").onclick=processEntry;
    


};




