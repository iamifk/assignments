"use strict";
var $ = function (id) {
    return document.getElementById(id);
};

var tax=0;

var calculateTax=function(income) {
    
    if(income >0 && income <= 9275)
        {
            tax=( income*10 )/100;
            $("tax").value=parseInt(tax);
}
    else if(income >9275 && income <= 37650)
        {
            
        
            tax=(income-9275)
            tax=(tax*15)/100;
            tax=tax+927.50
            $("tax").value=(tax);
}
    else if(income >37650 && income <= 91150)
        {
            
        
            tax=(income-37650)
            tax=(tax*25)/100;
            tax=tax+5183.75;
            $("tax").value=parseInt(tax);
}
    
    
    
    
    
    
};






var processEntry =function(){
var income=$("income").value;

if (isNaN(income)) 
{
 alert("Income must be numeric");
}
else if(income <=0 )
{
alert("Income must be greater than 0");
}

    else{

    calculateTax(income);
        
}
};



window.onload = function () {
    $("calculate").onclick = processEntry;
};