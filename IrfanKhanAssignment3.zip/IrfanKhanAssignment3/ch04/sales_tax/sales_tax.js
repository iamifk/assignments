var $ = function (id) {
    return document.getElementById(id); 
};

var sales_tax =0.0;


var calculateSalesTax=function(tax_rate,subtotal) {
sales_tax=(subtotal *tax_rate)/100;
sales_tax=sales_tax.toFixed(2);
    return sales_tax;
};



var clearthevalues=function(){
    $("subtotal").value="";
    $("tax_rate").value="";
    $("sales_tax").value="";
    $("total").value="";
    }


var processEntries =function(){
var subtotal=$("subtotal").value;
var tax_rate=parseFloat($("tax_rate").value);
if (isNaN(subtotal) || isNaN(tax_rate)) 
{
 alert("Both entries must be numeric");
}
else if(subtotal <=0 || subtotal >10000)
{
alert("Subtotal entries must be greater than zero and less than 10000");
}
else if(tax_rate <=0 || tax_rate >12)
{
alert("Tax rate must be greater than zero and less than 12");
}
    else{

        var salessTax = calculateSalesTax(tax_rate,subtotal);
        $("sales_tax").value=salessTax;
var total= parseFloat(subtotal)+parseFloat(salessTax);
        $("total").value=total;
        
}
};

 window.onload=function() {
$("calculate").onclick=processEntries;
     $("clear").onclick=clearthevalues;


};


