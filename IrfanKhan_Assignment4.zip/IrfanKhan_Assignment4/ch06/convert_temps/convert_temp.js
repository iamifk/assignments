"use strict";
var $ = function (id) {
    return document.getElementById(id);
};


var clearTextBoxes = function () {
    $("degrees_entered").value = "";
    $("degrees_computed").value = "";
};

function toFahrenheit() {
    $("degree_label_1").innerHTML = "Enter c degrees";
    $("degree_label_2").innerHTML = "Degrees fahrenheit";
    clearTextBoxes();
}

function toCelsius() {
    $("degree_label_2").innerHTML = "Degrees Celsius";
    $("degree_label_1").innerHTML = "Enter F degrees";
    clearTextBoxes();
}

function convertTemp() {
    var ftemp = parseInt($("degrees_entered").value);
    if (isNaN(ftemp)) {
        alert("enter Numbers only");
        clearTextBoxes();
        $("degrees_entered").focus();
    } else {
        if ($("to_celsius").checked) {
            var ran = 32;
            var cel = parseInt((ftemp - ran) * 5 / 9);
            $("degrees_computed").value = cel;
        }
        if ($("to_fahrenheit").checked) {
            var ran = 32;
            var fat = parseInt(ftemp * (9 / 5)) + ran;
            $("degrees_computed").value = fat;
        }
    }
}

window.onload = function () {
    $("convert").onclick = convertTemp;
    $("to_celsius").onclick = toCelsius;
    $("to_fahrenheit").onclick = toFahrenheit;
    $("degrees_entered").focus();
};