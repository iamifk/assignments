var names = ["Jenny", "Roddy", "Noumy", "Samra"];
var scores = [55, 62, 33, 77];

var $ = function (id) {
    return document.getElementById(id);
};



window.onload = function () {
    $("add").onclick = addScore;
    $("display_results").onclick = displayResults;
    $("display_scores").onclick = displayScores;
};


function addScore() {
    var name_new = $("name").value;
    var score_new = $("score").value;
    score_new = parseInt(score_new);

    if (name_new.length == 0 || score_new < 0 || score_new > 100 || isNaN(score_new)) {
        alert("Enter proper name and score from 0 to 100 to process this function");
    } else {
        names[names.length] = name_new;
        scores[scores.length] = score_new;
        displayResults();
        $("name").value = "";
        $("score").value = "";
    }
    $("name").focus();

}

function displayResults() {
    results = "";

    var total = 0;
    var average = 0;
    var high = 0;
    var highIndex = 0;

    for (var j = 0; j < scores.length; j++) {
        total += scores[j];
        if (scores[j] > high) {
            high = scores[j];
            highIndex = j;
        }
    }

    average = total / scores.length;

    average = parseFloat(average.toFixed(2));

    $("results").innerHTML = "<h2>Results</h2><p>Average Score = " + average + "</p><br><p>High score = " + scores[highIndex] + " with a score of " + names[highIndex];

    $("scores_table").innerHTML = "";
}


function displayScores() {
    $("results").value = "";
    $("scores_table").innerHTML = "";

    var table = $("scores_table");

    var tBody = table.tBodies[0];

    if (tBody == undefined) {

        tBody = document.createElement("tBody");
        table.appendChild(tBody);
    }

    $("results").innerHTML = "<h2>Scores</h2><tr><th><b>Name</b></th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Score<b></th></tr>";

    for (i = 0; i < scores.length; i++) {
        var row = tBody.insertRow(-1);

        var textNode = document.createTextNode(names[i]);
        var cellNode = row.insertCell(-1);
        cellNode.appendChild(textNode);

        var scoreNode = document.createTextNode(scores[i]);
        var cellNode2 = row.insertCell(-1);
        cellNode2.appendChild(scoreNode);
    }


}