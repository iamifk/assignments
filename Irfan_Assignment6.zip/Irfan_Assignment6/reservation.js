$(document).ready(function () {
    var emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
    $("#submit").click(function (evt) {
        var arvdate = $("#arrival_date").val();
        var night = $("#nights").val();
        var name = $("#name").val();
        var emailAddress = $("#email").val();
        var phone = $("#phone").val();
        var phonepattern = /^(\d{3})-+(\d{3})-+(\d{4})$/;
        var isValid = true;
        if (!arvdate) {
            $("#arrival_date").next().text("This field is required.");
            isValid = false;
        } else {
            $("#arrival_date").next().text("");
        }
        if (isNaN(night) || !night) {
            $("#nights").next().text("This field is required & it should be number");
            isValid = false;
        } else {
            $("#nights").next().text("");
        }
        // validate the  email address no 1
        if (!emailAddress || !emailPattern.test(emailAddress)) {
            $("#email").next().text("This field is required & should match pattern");
            isValid = false;
        } else {
            $("#email").next().text("");
        }
        // validate the name entry
        if (!name) {
            $("name").next().text("This field is required.");
            isValid = false;
        } else {
            $("name").next().text("");
        }
        if (!phone || !phonepattern.test(phone)) {
            $("#phone").next().text("This field is required & should match pattern");
            isValid = false;
        } else {
            $("#phone").next().text("");
        }
        console.log(isValid);
        // submit the form if all entries are valid
        if (!isValid) {
            evt.preventDefault();
        }
    }); // end click
}); // end ready