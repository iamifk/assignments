$(document).ready(function() {
    var s_scores = [];
    var s_names = [];
    var s_index = 0;
    var s_total = 0;
  
    function displayScores() {
      while (s_index < s_names.length) {
        $("#scores").val($("#scores").val() + s_names[s_index] + "\n");
        s_total += parseFloat(s_scores[s_index]);
        s_index++;
      }
  
      var s_average = s_total / s_names.length;
      $("#average_score").val(s_average);
    }
  
    $("#add_button").click(function(){
      if (isNaN($("#score").val()) || $("#score").val() < 0) {
        alert("Please enter a valid number");
      }
  
      if ($("#first_name").val() == "" || $("#last_name").val() == "") {
        alert("Please enter a valid name ");
      }
  
      if (
        !isNaN($("#score").val()) &&
        $("#score").val() >= 0 &&
        $("#first_name").val() != "" &&
        $("#last_name").val() != ""
      ) {
        parseFloat(s_scores.push($("#score").val()));
        s_names.push(
          $("#last_name").val() +
            ", " +
            $("#first_name").val() +
            " : " +
            $("#score").val()
        );
        displayScores();
      }
  
      $("#first_name").val("");
      $("#last_name").val("");
      $("#score").val("");
      $("#first_name").focus();
    }); //
  
    $("#clear_button").click(function(){
      s_scores = [];
      s_names = [];
  
      $("#average_score").val("");
      $("#first_name").val("");
      $("#last_name").val("");
      $("#scores").val("");
      $("#score").val("");
  
      $("#first_name").focus();
    });
  
    $("#sort_button").click(function(){
      $("#scores").val("");
  
      var sort = s_names.sort();
  
      for (var i = 0; i < s_names.length; i++) {
        $("#scores").val($("#scores").val() + sort[i] + "\n");
      }
    });
  });